import { r as renderer } from "./errorRenderer-ebf63d74.js";
import "./config-b4fa35bb.js";
import "./utils-872dfc50.js";
import "./setupGraphViewbox-16a0ba81.js";
import "./commonDb-7f40ab5a.js";
const getStyles = () => ``;
const styles = getStyles;
const diagram = {
  db: {
    clear: () => {
    }
  },
  styles,
  renderer,
  parser: {
    parser: { yy: {} },
    parse: () => {
    }
  },
  init: () => {
  }
};
export {
  diagram
};
//# sourceMappingURL=errorDiagram-8d01edd9.js.map
