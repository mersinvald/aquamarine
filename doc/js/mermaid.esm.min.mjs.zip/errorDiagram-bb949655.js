import { r as renderer } from "./errorRenderer-d05351b9.js";
import "d3";
import "./config-389b86ff.js";
import "dompurify";
import "dayjs";
import "khroma";
import "./utils-d5eeff82.js";
import "@braintree/sanitize-url";
import "./setupGraphViewbox-e35e4124.js";
import "./commonDb-2ace122b.js";
import "lodash-es/memoize.js";
const getStyles = () => ``;
const styles = getStyles;
const diagram = {
  db: {
    clear: () => {
    }
  },
  styles,
  renderer,
  parser: {
    parser: { yy: {} },
    parse: () => {
    }
  },
  init: () => {
  }
};
export {
  diagram
};
//# sourceMappingURL=errorDiagram-bb949655.js.map
