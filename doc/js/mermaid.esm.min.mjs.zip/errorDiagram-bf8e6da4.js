import { r } from "./errorRenderer-a3c4bedb.js";
import "./config-e567ef17.js";
import "./utils-aa888deb.js";
import "./setupGraphViewbox-a4603a92.js";
import "./commonDb-4dc3d465.js";
const t = () => "", e = t, m = {
  db: {
    clear: () => {
    }
  },
  styles: e,
  renderer: r,
  parser: {
    parser: { yy: {} },
    parse: () => {
    }
  },
  init: () => {
  }
};
export {
  m as diagram
};
//# sourceMappingURL=errorDiagram-bf8e6da4.js.map
