import { S as t, o as n, q as o } from "./config-e567ef17.js";
function a(e) {
  return typeof e == "string" ? new t([document.querySelectorAll(e)], [document.documentElement]) : new t([o(e)], n);
}
export {
  a as s
};
//# sourceMappingURL=selectAll-8155f162.js.map
