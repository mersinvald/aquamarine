import { p as e, f as o } from "./add-html-label-6e56ed67.js";
import { f as t, a } from "./styles-0beab977.js";
import { h as i } from "./config-e567ef17.js";
import "./utils-aa888deb.js";
import "./setupGraphViewbox-a4603a92.js";
import "./commonDb-4dc3d465.js";
import "./mermaidAPI-04b5c286.js";
import "./errorRenderer-a3c4bedb.js";
import "./isPlainObject-a5cb4071.js";
import "./array-2ff2c7a6.js";
import "./constant-2fe7eae5.js";
import "./layout-d6d8be39.js";
import "./index-e6caf2ad.js";
import "./edges-0979260b.js";
import "./svgDraw-c034b55e.js";
import "./selectAll-8155f162.js";
const y = {
  parser: e,
  db: o,
  renderer: t,
  styles: a,
  init: (r) => {
    r.flowchart || (r.flowchart = {}), r.flowchart.arrowMarkerAbsolute = r.arrowMarkerAbsolute, i({ flowchart: { arrowMarkerAbsolute: r.arrowMarkerAbsolute } }), t.setConf(r.flowchart), o.clear(), o.setGen("gen-2");
  }
};
export {
  y as diagram
};
//# sourceMappingURL=flowDiagram-v2-2a7e193a.js.map
