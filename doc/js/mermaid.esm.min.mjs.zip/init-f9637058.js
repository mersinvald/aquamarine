function t(e, a) {
  switch (arguments.length) {
    case 0:
      break;
    case 1:
      this.range(e);
      break;
    default:
      this.range(a).domain(e);
      break;
  }
  return this;
}
export {
  t as i
};
//# sourceMappingURL=init-f9637058.js.map
